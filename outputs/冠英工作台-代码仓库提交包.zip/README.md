# 冠英工作台

面向商用车刹车片外贸销售。以社媒和网站询盘为入口，串联 AI 辅助分析、目录选型、报价草稿、客户档案、跟进和管理员报表。

## 本地演示

使用 Node.js 和 Python 3.12 或更新版本，在仓库根目录运行以下 Windows 命令。

~~~text
npm ci
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
npm run build
.venv\Scripts\python -m uvicorn main:app --host 127.0.0.1 --port 8000
~~~

打开 http://127.0.0.1:8000。销售可在本机注册。初始本机管理员账号为 admin，密码为 123456，可在后台修改密码。也可使用 Docker Compose，默认绑定本机 8000 端口。

进入「社媒线索」，载入车队示例并分析。打开客户对话，填写 GYS-010、SAF 车桥与 300 套。录入演示对客单价后，生成报价草稿并带回对话，再保存客户和跟进。

随仓库提供的是合成目录和空图片索引。未配置搜索密钥时使用演示结果。真实模型、社媒、官网和孚盟 CRM 依赖企业授权和配置。环境变量可参考 .env.example。

构建后运行 python smoke.py，可使用隔离数据库检查主要接口。
